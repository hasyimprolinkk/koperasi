<?php

namespace App\Http\Controllers;

use App\Models\Member;
use App\Models\Saving;
use App\Models\SavingHistory;
use PDF;
use Illuminate\Http\Request;

class CetakController extends Controller
{
    public function cetak($id){
        // $cetak = SavingHistory::where('anggota_id', $id)->get();
        $anggota = Member::whereId($id)->first()->nama;
        $savings_history = SavingHistory::whereAnggotaId($id)->orderBy('id', 'asc')->get();
        $total_credit = SavingHistory::whereAnggotaId($id)->sum('kredit');
        $total_debet = SavingHistory::whereAnggotaId($id)->sum('debet');
        $balance = Saving::whereAnggotaId($id)->first();
        
        // return view('mutations.cetak',compact('savings_history', 'total_credit', 'total_debet', 'balance', 'anggota'));
        $pdf = PDF::loadview('mutations.cetak', compact('savings_history', 'total_credit', 'total_debet', 'balance', 'anggota'))->setPaper('a4', 'landscape');
        return $pdf->download(date('dmYHi').'_mutasi.pdf');
    }

    public function mutasi($tgl_awal, $tgl_akhir){
        $cetak = SavingHistory::whereBetween('created_at',[$tgl_awal, $tgl_akhir])->get();
        $pdf = PDF::loadview('ctkall.mutasiall', compact('cetak', 'tgl_awal', 'tgl_akhir'))->setPaper('a4', 'landscape');
        return $pdf->download(date('dmYHi').'_mutasi.pdf');
    }
}
