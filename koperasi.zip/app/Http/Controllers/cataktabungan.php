<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SavingHistory;
use DB;

class cataktabungan extends Controller
{
    public function cetak($id){
        //dd("Tanggal Awal : ".$tgl_awal, "Tanngal Akhir : ".$tgl_akhir);
        //$cetaka = SavingHistory::whereIn('anggota_id', $id)->get();
        //dd($cetak);
        //return view('mutations.cetak',compact('cetaka'));
        $cetaka = DB::table('riwayat_tabungan')->where('anggota_id', $id)->get();
        //dd($user);
        return view('mutations.cetak',compact('cetaka'));
    }

    public function cetakall($tgl_awal, $tgl_akhir){
        //dd("Tanggal Awal : ".$tgl_awal, "Tanngal Akhir : ".$tgl_akhir);
        //$cetaka = SavingHistory::whereIn('anggota_id', $id)->get();
        //dd($cetak);
        //return view('mutations.cetak',compact('cetaka'));
        $cetakall = SavingHistory::whereBetween('created_at',[$tgl_awal, $tgl_akhir])->get();
        //dd($user);
        return view('ctkall.cetakall',compact('cetakall'));
    }
}
