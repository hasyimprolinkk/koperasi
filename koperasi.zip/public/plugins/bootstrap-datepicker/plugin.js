require.config({
    shim: {
        'datepicker': ['jquery','core'],
    },
    paths: {
        'datepicker': 'plugins/bootstrap-datepicker/js/bootstrap-datepicker.min',
    }
});