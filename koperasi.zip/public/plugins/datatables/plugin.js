require.config({
    shim: {
        'datatables': ['jquery','core'],
    },
    paths: {
        'datatables': 'plugins/datatables/datatables.min',
    }
});