require.config({
    shim: {
        'input-mask': ['jquery', 'core']
    },
    paths: {
        'input-mask': 'plugins/input-mask/js/jquery.mask.min'
    }
});