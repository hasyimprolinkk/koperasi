<a class="btn btn-sm btn-info" href="{{ route('withdrawals.show', $withdrawal->id) }}">Detail</a>
