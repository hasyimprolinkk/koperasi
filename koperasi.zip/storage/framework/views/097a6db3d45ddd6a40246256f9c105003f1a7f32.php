<?php $__env->startSection('content-app'); ?>
<div class="row row-cards">
        <div class="col-8 offset-md-2">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Edit Profil</h3>
                <div class="card-options">
                    <a href="<?php echo e(url('/profile')); ?>" class="btn btn-sm btn-pill btn-secondary">Kembali</a>
                </div>
            </div>
            <form action="<?php echo e(url('/profile/' . $user->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PATCH')); ?>

                <div class="card-body">
                    <div class="form-group">
                        <div class="row align-items-center">
                            <label class="col-sm-3">Nama</label>
                            <div class="col-sm-9">
                                <input type="text" name="name" autocomplete="off" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('name', $user->name)); ?>">
                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row align-items-center">
                            <label class="col-sm-3">E-Mail</label>
                            <div class="col-sm-9">
                                <input type="email" name="email" autocomplete="off" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('email', $user->email)); ?>">
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback"><?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row align-items-center">
                            <label class="col-sm-3">Password</label>
                            <div class="col-sm-9">
                                <input type="password" name="password" autocomplete="off" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" aria-describedby="passwordHelpBlock">
                                <small id="passwordHelpBlock" class="form-text text-muted">
                                    Biarkan jika tidak diubah.
                                </small>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback"><?php echo e($errors->first('password')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-right">
                    <button type="submit" class="btn btn-primary">Simpan Profil</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>