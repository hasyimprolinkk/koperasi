<?php $__env->startSection('content'); ?>
<div class="page">
    <div class="flex-fill">
        <?php echo $__env->make('shared.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="my-3 my-md-5">
            <div class="container">
                <div class="page-header">
                    <h1 class="page-title"><?php echo $__env->yieldContent('page-title'); ?></h1>
                </div>
                <?php echo $__env->yieldContent('content-app'); ?>
            </div>
        </div>
    </div>
    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>