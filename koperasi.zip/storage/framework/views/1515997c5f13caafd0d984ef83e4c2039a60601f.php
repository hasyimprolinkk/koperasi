<?php $__env->startSection('content-app'); ?>
<div class="row row-cards row-deck">
    <div class="col-10 offset-md-1">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Edit Anggota</h3>
                <div class="card-options">
                    <a href="<?php echo e(route('members.index')); ?>" class="btn btn-sm btn-pill btn-secondary">Kembali</a>
                </div>
            </div>
            <form action="<?php echo e(route('members.update', $member->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PATCH')); ?>

                <div class="card-body">
                    <div class="form-group">
                        <label class="form-label">NIK</label>
                        <input type="text" name="nik" class="form-control<?php echo e($errors->has('nik') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('nik', $member->nik)); ?>">
                        <?php if($errors->has('nik')): ?>
                            <span class="invalid-feedback"><?php echo e($errors->first('nik')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Nama Lengkap</label>
                                <input type="text" name="nama" class="form-control<?php echo e($errors->has('nama') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('nama', $member->nama)); ?>">
                                <?php if($errors->has('nama')): ?>
                                    <span class="invalid-feedback"><?php echo e($errors->first('nama')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('email', $member->email)); ?>">
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback"><?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Tempat Lahir</label>
                                <input type="text" name="tempat_lahir" class="form-control<?php echo e($errors->has('tempat_lahir') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('tempat_lahir', $member->tempat_lahir)); ?>">
                                <?php if($errors->has('tempat_lahir')): ?>
                                    <span class="invalid-feedback"><?php echo e($errors->first('tempat_lahir')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Tanggal Lahir</label>
                                <input type="text" name="tanggal_lahir" id="datepicker" autocomplete="off" class="form-control<?php echo e($errors->has('tanggal_lahir') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('tanggal_lahir', $member->tanggal_lahir)); ?>">
                                <?php if($errors->has('tanggal_lahir')): ?>
                                    <span class="invalid-feedback"><?php echo e($errors->first('tanggal_lahir')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">No Telepon</label>
                                <input type="text" name="no_hp" class="form-control<?php echo e($errors->has('no_hp') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('no_hp', $member->no_hp)); ?>">
                                <?php if($errors->has('no_hp')): ?>
                                    <span class="invalid-feedback"><?php echo e($errors->first('no_hp')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Jenis Kelamin</label>
                                <div class="custom-controls-stacked">
                                    <label class="custom-control custom-radio custom-control-inline">
                                        <input type="radio" class="custom-control-input<?php echo e($errors->has('jenkel') ? ' is-invalid' : ''); ?>" name="jenkel" value="L"<?php echo old('jenkel', $member->jenkel) == 'L' ? ' checked=""' : ''; ?>>
                                        <span class="custom-control-label">Laki-laki</span>
                                    </label>
                                    <label class="custom-control custom-radio custom-control-inline">
                                        <input type="radio" class="custom-control-input<?php echo e($errors->has('jenkel') ? ' is-invalid' : ''); ?>" name="jenkel" value="P"<?php echo old('jenkel', $member->jenkel) == 'L' ? '' : ' checked=""'; ?>>
                                        <span class="custom-control-label">Perempuan</span>
                                    </label>
                                </div>
                                <?php if($errors->has('jenkel')): ?>
                                    <span class="invalid-feedback"><?php echo e($errors->first('jenkel')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Agama</label>
                                <select class="form-control<?php echo e($errors->has('agama') ? ' is-invalid' : ''); ?>" name="agama">
                                    <option value="">-- Pilih --</option>
                                    <?php $__currentLoopData = religions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($religion); ?>" <?php echo (old('agama', $member->agama) == $religion ? "selected=\"selected\"" : ""); ?>><?php echo e($religion); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('agama')): ?>
                                    <span class="invalid-feedback"><?php echo e($errors->first('agama')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Pekerjaan</label>
                                <input type="text" name="pekerjaan" class="form-control<?php echo e($errors->has('pekerjaan') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('pekerjaan', $member->pekerjaan)); ?>">
                                <?php if($errors->has('pekerjaan')): ?>
                                    <span class="invalid-feedback"><?php echo e($errors->first('pekerjaan')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Alamat</label>
                        <textarea rows="2" class="form-control<?php echo e($errors->has('alamat') ? ' is-invalid' : ''); ?>" name="alamat"><?php echo e(old('alamat', $member->alamat)); ?></textarea>
                        <?php if($errors->has('alamat')): ?>
                            <span class="invalid-feedback"><?php echo e($errors->first('alamat')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-footer text-right">
                    <button type="submit" class="btn btn-primary">Simpan Anggota</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>