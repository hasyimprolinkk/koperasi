<a class="btn btn-sm btn-info" href="<?php echo e(route('deposits.show', $deposit->id)); ?>">Detail</a>
