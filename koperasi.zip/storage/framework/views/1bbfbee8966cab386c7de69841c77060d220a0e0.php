<form action="<?php echo e(route('members.destroy', $member->id)); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('DELETE')); ?>

    <a class="btn btn-sm btn-info" href="<?php echo e(route('members.show', $member->id)); ?>">Detail</a>
    <a class="btn btn-sm btn-primary" href="<?php echo e(route('members.edit', $member->id)); ?>">Ubah</a>
    <button class="btn btn-sm btn-danger" type="submit" onclick="return confirm('Yakin ingin menghapus data?')">Hapus</button>
</form>
