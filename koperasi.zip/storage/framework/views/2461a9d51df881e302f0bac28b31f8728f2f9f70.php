<div class="card">
    <div class="card-header">
        <h3 class="card-title">Hasil Mutasi</h3>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table card-table table-vcenter text-nowrap">
                <thead>
                
                <a href="" onclick="this.href='cetak/<?php echo e($anggota_id); ?>'" target="_blank" class="btn btn-primary">Cetak Mutasi <i class="fa fa-print"></i></a>
                
                
                    <tr>
                        <th class="w-1">ID.</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th class="text-right">Debet</th>
                        <th class="text-right">Kredit</th>
                        <th class="text-right">Saldo</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $savings_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saving_history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($saving_history->anggota_id); ?></td>
                            <td><?php echo e($saving_history->tanggal); ?></td>
                            <td><?php echo e($saving_history->keterangan); ?></td>
                            <td class="text-right"><?php echo e(format_rupiah($saving_history->debet)); ?></td>
                            <td class="text-right"><?php echo e(format_rupiah($saving_history->kredit)); ?></td>
                            <td class="text-right"><?php echo e(format_rupiah($saving_history->saldo)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6">Riwayat Mutasi tidak ditemukan.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($savings_history->count() > 0): ?>
            <table class="table">
                <tbody>
                    <tr>
                        <td style="width: 20%;" class="font-weight-bold text-muted">Total Kredit</td>
                        <td><?php echo e(format_rupiah($total_credit)); ?></td>
                    </tr>
                    <tr>
                        <td class="font-weight-bold text-muted">Total Debet</td>
                        <td><?php echo e(format_rupiah($total_debet)); ?></td>
                    </tr>
                    <tr>
                        <td class="font-weight-bold text-muted">Saldo Akhir</td>
                        <td><?php echo e(format_rupiah($balance->saldo)); ?></td>
                    </tr>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>