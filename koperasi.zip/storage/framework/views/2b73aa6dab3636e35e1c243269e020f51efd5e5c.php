<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Aplikasi Koperasi Reza Jaya</title>
    <style>
        @page{
            margin: 2.5cm 2.5cm 2.5cm 2.5cm;
        }

        .table, .bordir {
            border: 1px solid black;
            border-collapse: collapse;
        }
    
        hr.solid {
        border-top: 2px solid #000000;
        }

        #data{
            width: 100%;
        }

    </style>
    </head>

<body>

    <table>
        <tr>
            <!-- <td><img src="" width="80px" class="mr-3" alt=""></td> -->
            <td>
                <div style="text-align: center;">
                    <h1 style="margin-bottom: 15px;">Aplikasi Koperasi Reza Jaya</h1>
                </div>
            </td>
        </tr>
    </table>
    <hr class="solid">
    <div>
            <h4 style="margin-top: 4px; margin-bottom: -15px;">List Laporan Riwayat Tabungan</h4>
            <br>
        </div>
        <hr class="solid">
        <br>
        <div style="margin-top: 3px; margin-bottom: 3px;">
            <table id="data">
                <tr>
                    <td>Petugas </td>
                    <td class="">: <?php echo e(Auth::user()->name); ?></td>
                </tr>
                <tr>
                    <td>Tanggal </td>
                    <td>: <?php echo e(date('d F Y', strtotime($tgl_awal))); ?> s/d <?php echo e(date('d F Y', strtotime($tgl_akhir))); ?></td>
                </tr>
            </table>
        </div>
        <br>
        <table style="width: 100%;" cellpadding="5" class="table">
            <thead>    
                <tr>
                    <th class="bordir" scope="col">No</th>
                    <th class="bordir">Nama</th>
                    <th class="bordir">Tanggal</th>
                    <th class="bordir">Keterangan</th>
                    <th class="bordir">Debet</th>
                    <th class="bordir">Kredit</th>
                    <th class="bordir">Saldo</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($cetak as $ctk=>$c) : ?>
                <tr>
                    <td class="bordir"><?php echo e($ctk+1); ?></td>
                    <td class="bordir"><?php echo e($c->member->nama); ?></td>
                    <td class="bordir"><?php echo e($c->tanggal); ?></td>
                    <td class="bordir"><?php echo e($c->keterangan); ?></td>
                    <td class="text-right bordir"><?php echo e(format_rupiah($c->debet)); ?></td>
                    <td class="text-right bordir"><?php echo e(format_rupiah($c->kredit)); ?></td>
                    <td class="text-right bordir"><?php echo e(format_rupiah($c->saldo)); ?></td>
                    
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

</body>

</html>