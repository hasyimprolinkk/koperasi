<?php $__env->startSection('content-app'); ?>
<div class="row row-cards row-deck">
    <div class="col-10 offset-md-1">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Detail Penarikan</h3>
                <div class="card-options">
                    <a href="<?php echo e(route('withdrawals.index')); ?>" class="btn btn-sm btn-pill btn-secondary">Kembali</a>
                </div>
            </div>
            <table class="table card-table">
                <tbody>
                    <tr>
                        <td style="width: 25%;" class="text-muted">Anggota</td>
                        <td>
                            <a href="<?php echo e(route('members.show', $withdrawal->anggota_id)); ?>" target="_blank"><?php echo e($withdrawal->member->nama); ?> - <?php echo e($withdrawal->member->nik); ?></a>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-muted">Jumlah Penarikan</td>
                        <td><?php echo e(format_rupiah($withdrawal->jumlah)); ?></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Keterangan</td>
                        <td><?php echo e($withdrawal->keterangan); ?></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Tanggal</td>
                        <td><?php echo e($withdrawal->created_at->format('d F Y H:i')); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>