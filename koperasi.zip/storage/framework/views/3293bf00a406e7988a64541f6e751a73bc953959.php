<footer class="footer">
    <div class="container">
        <div class="row align-items-center flex-row-reverse">
            <div class="col-auto ml-lg-auto">
            </div>
            <div class="col-12 col-lg-auto mt-3 mt-lg-0 text-center">
                 <a href=".">APLIKASI MONITORING</a>
            </div>
        </div>
    </div>
</footer>
