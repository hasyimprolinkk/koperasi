<?php $__env->startSection('content-app'); ?>
<div class="row row-cards row-deck">
    <div class="col-10 offset-md-1">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Detail Anggota</h3>
                <div class="card-options">
                    <a href="<?php echo e(route('members.index')); ?>" class="btn btn-sm btn-pill btn-secondary">Kembali</a>
                    <a class="btn btn-sm btn-pill btn-primary ml-2" href="<?php echo e(route('members.edit', $member->id)); ?>">Ubah</a>
                </div>
            </div>
            <table class="table card-table">
                <tbody>
                    <tr>
                        <td style="width: 25%;" class="text-muted">NIK</td>
                        <td><?php echo e($member->nik); ?></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Nama</td>
                        <td><?php echo e($member->nama); ?></td>
                    </tr>
                    <tr>
                        <td class="text-muted">E-Mail</td>
                        <td><?php echo e($member->email); ?></td>
                    </tr>
                    <tr>
                        <td class="text-muted">No. Telp</td>
                        <td><?php echo e($member->no_hp); ?></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Jenis Kelamin</td>
                        <td><?php echo e($member->jenkel); ?></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Tempat, Tanggal Lahir</td>
                        <td><?php echo e($member->tempat_lahir); ?>, <?php echo e($member->tanggal_lahir->format('d F Y')); ?></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Agama</td>
                        <td><?php echo e($member->agama); ?></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Pekerjaan</td>
                        <td><?php echo e($member->pekerjaan); ?></td>
                    </tr>
                    <tr>
                        <td class="text-muted">Alamat</td>
                        <td><?php echo e($member->alamat); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>