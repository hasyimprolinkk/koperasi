<!DOCTYPE html>
<html>
    <title>CETAK DATA</title>
</head>
    <h2 align="center">Laporan Data</h2>
    <table class="table table-striped table-bordered zero-configuration" border="1" style="width: 100%" align="center">
    <thead>
        <tr bgcolor="#00ff80">
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th class="text-right">Debet</th>
                        <th class="text-right">Kredit</th>
                        <th class="text-right">Saldo</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $cetakall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
                            <td><?php echo e($e+1); ?></td>
                            <td><?php echo e($item->tanggal); ?></td>
                            <td><?php echo e($item->keterangan); ?></td>
                            <td class="text-right"><?php echo e(format_rupiah($item->debet)); ?></td>
                            <td class="text-right"><?php echo e(format_rupiah($item->kredit)); ?></td>
                            <td class="text-right"><?php echo e(format_rupiah($item->saldo)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>