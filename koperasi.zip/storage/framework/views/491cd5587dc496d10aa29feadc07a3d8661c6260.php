<?php $__env->startSection('content-app'); ?>
<div class="row row-cards row-deck">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Cek Mutasi</h3>
            </div>
            <form>
                <div class="card-body">
                    <div class="form-group">
                        <div class="row align-items-center">
                            <label class="col-sm-2">Anggota</label>
                            <div class="col-sm-10">
                                <select class="form-control<?php echo e($errors->has('anggota') ? ' is-invalid' : ''); ?>" id="select2" name="anggota">
                                    <option value="">-- Pilih Anggota --</option>
                                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($member->id); ?>" <?php echo (old('anggota') == $member->id ? "selected=\"selected\"" : ""); ?>><?php echo e($member->nama); ?> - <?php echo e($member->nik); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('anggota')): ?>
                                    <span class="invalid-feedback"><?php echo e($errors->first('anggota')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-right">
                    <button id="btn-check-mutations" class="btn btn-primary">Cek Mutasi</button>
                </div>
                <div class="card-footer text-right">
                <button id="btn-check-mutations" class="btn btn-primary" data-toggle="modal"data-target="#tbh">Laporan</button> 
                <div id="tbh" class="modal fade" role="dialog">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" data-dismiss="modal">&times;</button>
                                                        <h4 class="modal-title">Cetak Data</h4>
                                                </div>
                                        <?php echo csrf_field(); ?>
                                    <div class="modal-body">
                                      <div class="form-group">
                                        <label class="control-label" for="exampleInputEmail1">Tgl Awal</label>
                                        <input class="form-control" type="date" name="tgl_awal" id="tgl_awal" aria-describedby="emailHelp" required="required">
                                      </div>
                                      <div class="form-group">
                                        <label class="control-label" for="exampleInputEmail1">Tgl Akhir</label>
                                        <input class="form-control" type="date" name="tgl_akhir" id="tgl_akhir" aria-describedby="emailHelp" required="required">
                                      </div>
                                      <div class="modal-footer">
                                        <a href="" onclick="this.href='cetakall/'+  document.getElementById('tgl_awal').value + '/' + document.getElementById('tgl_akhir').value " target="_blank" class="btn btn-primary">Cetak  <i class="fa fa-print"></i></a>
                                       </div>
                                      </div>
                                     </div>
                                     </div>
                                            </div>
                </div>
            </form>
        </div>
        <div class="result"></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://select2.github.io/select2-bootstrap-theme/css/select2-bootstrap.css">

<script>
require(['jquery', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js'], function ($, select2) {
    $(document).ready(function () {
        $('#select2').select2({
            theme: "bootstrap",
        });

        $('#btn-check-mutations').click(function(e) {
            e.preventDefault();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var anggota_id = $('select[name="anggota"]').val();
            if (anggota_id == "") {
                console.log('Clicked null');
            } else {
                $.ajax({
                    type: "GET",
                    url: "<?php echo e(url('mutations/check-mutations')); ?>",
                    data: {anggota_id: anggota_id},
                    success: function(data) {
                        $('.result').html(data.html);
                    }
                });
            }

        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>