<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Aplikasi Koperasi Reza Jaya</title>
    <style>
        @page{
            margin: 2.5cm 2.5cm 2.5cm 2.5cm;
        }

        .table, .bordir {
            border: 1px solid black;
            border-collapse: collapse;
        }
    
        hr.solid {
        border-top: 2px solid #000000;
        }

        #data{
            width: 100%;
        }

    </style>
    </head>

<body>

    <table>
        <tr>
            <!-- <td><img src="" width="80px" class="mr-3" alt=""></td> -->
            <td>
                <div style="text-align: center;">
                    <h1 style="margin-bottom: 15px;">Aplikasi Koperasi Reza Jaya</h1>
                </div>
            </td>
        </tr>
    </table>
    <hr class="solid">
    <div>
            <h4 style="margin-top: 4px; margin-bottom: -15px;">Riwayat Tabungan</h4>
            <br>
        </div>
        <hr class="solid">
        <br>
        <div style="margin-top: 3px; margin-bottom: 3px;">
            <table style="width: 50%;">
                <tr>
                    <td>Petugas </td>
                    <td class="">: <?php echo e(Auth::user()->name); ?></td>
                </tr>
                <tr>
                    <td>Tanggal </td>
                    <td>: <?php echo e(date('d F Y', strtotime(now()))); ?></td>
                </tr>
                <tr>
                    <td>Anggota </td>
                    <td class="">: <?php echo e($anggota); ?></td>
                </tr>
            </table>
        </div>
        <br>
        <table style="width: 100%;" cellpadding="5" class="table">
            <thead>    
                <tr>
                    <th class="bordir" scope="col">No</th>
                    <th class="bordir">Tanggal</th>
                    <th class="bordir">Keterangan</th>
                    <th class="bordir">Debet</th>
                    <th class="bordir">Kredit</th>
                    <th class="bordir">Saldo</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $savings_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e=>$saving_history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="bordir"><?php echo e($e+1); ?></td>
                        <td class="bordir"><?php echo e($saving_history->tanggal); ?></td>
                        <td class="bordir"><?php echo e($saving_history->keterangan); ?></td>
                        <td class="bordir"><?php echo e(format_rupiah($saving_history->debet)); ?></td>
                        <td class="bordir"><?php echo e(format_rupiah($saving_history->kredit)); ?></td>
                        <td class="bordir"><?php echo e(format_rupiah($saving_history->saldo)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6">Riwayat Mutasi tidak ditemukan.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php if($savings_history->count() > 0): ?>
            <table style="width: 40%; float: right;" cellpadding="5">
                <tbody>
                    <tr>
                        <td align="right">Total Kredit</td>
                        <td align="right">: <?php echo e(format_rupiah($total_credit)); ?></td>
                    </tr>
                    <tr>
                        <td align="right">Total Debet</td>
                        <td align="right">: <?php echo e(format_rupiah($total_debet)); ?></td>
                    </tr>
                    <tr>
                        <td align="right">Saldo Akhir</td>
                        <td align="right">: <?php echo e(format_rupiah($balance->saldo)); ?></td>
                    </tr>
                </tbody>
            </table>
        <?php endif; ?>

</body>

</html>