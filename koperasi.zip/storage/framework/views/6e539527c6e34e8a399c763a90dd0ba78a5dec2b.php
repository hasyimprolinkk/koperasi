<a class="btn btn-sm btn-info" href="<?php echo e(route('withdrawals.show', $withdrawal->id)); ?>">Detail</a>
