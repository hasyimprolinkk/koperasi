<?php $__env->startSection('content-app'); ?>
<div class="row row-cards row-deck">
    <div class="col-10 offset-md-1">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Tambah Setoran</h3>
                <div class="card-options">
                    <a href="<?php echo e(route('deposits.index')); ?>" class="btn btn-sm btn-pill btn-secondary">Kembali</a>
                </div>
            </div>
            <form action="<?php echo e(route('deposits.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="form-group">
                        <div class="row align-items-center">
                            <label class="col-sm-2">Anggota</label>
                            <div class="col-sm-10">
                                <select class="form-control<?php echo e($errors->has('anggota') ? ' is-invalid' : ''); ?>" id="select2" name="anggota">
                                    <option value="">-- Pilih Anggota --</option>
                                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($member->id); ?>" <?php echo (old('anggota') == $member->id ? "selected=\"selected\"" : ""); ?>><?php echo e($member->nama); ?> - <?php echo e($member->nik); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('anggota')): ?>
                                    <span class="invalid-feedback"><?php echo e($errors->first('anggota')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row align-items-center">
                            <label class="col-sm-2">Jumlah Setoran</label>
                            <div class="col-sm-10">
                                <div class="input-group">
                                    <span class="input-group-prepend">
                                        <span class="input-group-text">Rp</span>
                                    </span>
                                    <input type="number" name="jumlah" autocomplete="off" class="form-control<?php echo e($errors->has('jumlah') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('jumlah')); ?>">
                                    <?php if($errors->has('jumlah')): ?>
                                        <span class="invalid-feedback"><?php echo e($errors->first('jumlah')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row align-items-center">
                            <label class="col-sm-2">Keterangan</label>
                            <div class="col-sm-10">
                                <input type="text" name="keterangan" autocomplete="off" class="form-control<?php echo e($errors->has('keterangan') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('keterangan')); ?>">
                                <?php if($errors->has('keterangan')): ?>
                                    <span class="invalid-feedback"><?php echo e($errors->first('keterangan')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-right">
                    <button type="submit" class="btn btn-primary">Tambah Setoran</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://select2.github.io/select2-bootstrap-theme/css/select2-bootstrap.css">

<script>
require(['jquery', 'selectize', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/i18n/id.js'], function ($, selectize, select2, select2id) {
    $(document).ready(function () {
        $('#select-beast').selectize({});
        $('#select2').select2({
            theme: "bootstrap",
            language: "id"
        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>