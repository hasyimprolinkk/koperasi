
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Hasil Mutasi</h3>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table card-table table-vcenter text-nowrap">
                <thead>
                <button type="button" class="btn btn-primary" data-toggle="modal"data-target="#tambah">Cetak Data</button>
                                        <div id="tambah" class="modal fade" role="dialog">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" data-dismiss="modal">&times;</button>
                                                        <h4 class="modal-title">Cetak Data</h4>
                                                </div>
                                        <?php echo csrf_field(); ?>
                                    <div class="modal-body">
                                      <div class="form-group">
                                        <label class="control-label" for="exampleInputEmail1">ID</label>
                                        <input class="form-control" type="number" name="id" id="id" aria-describedby="emailHelp" required="required">
                                      </div>
                                      <!-- <div class="form-group">
                                        <label class="control-label" for="exampleInputEmail1">Tgl Akhir</label>
                                        <input class="form-control" type="date" name="tgl_akhir" id="tgl_akhir" aria-describedby="emailHelp" required="required">
                                      </div> -->
                                      <div class="modal-footer">
                                        <a href="" onclick="this.href='cetak/'+  document.getElementById('id').value " target="_blank" class="btn btn-primary">Cetak  <i class="fa fa-print"></i></a>
                                       </div>
                                      </div>
                                     </div>
                                     </div>
                                            </div>
                    <tr>
                        <th class="w-1">ID.</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th class="text-right">Debet</th>
                        <th class="text-right">Kredit</th>
                        <th class="text-right">Saldo</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saving_history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($saving_history->anggota_id); ?></td>
                            <td><?php echo e($saving_history->tanggal); ?></td>
                            <td><?php echo e($saving_history->keterangan); ?></td>
                            <td class="text-right"><?php echo e(format_rupiah($saving_history->debet)); ?></td>
                            <td class="text-right"><?php echo e(format_rupiah($saving_history->kredit)); ?></td>
                            <td class="text-right"><?php echo e(format_rupiah($saving_history->saldo)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6">Riwayat Mutasi tidak ditemukan.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>